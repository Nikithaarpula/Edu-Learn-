import React from "react";
import { Link, useLocation } from "react-router-dom";
import { FaSignOutAlt } from "react-icons/fa";
import "./Navbar.css";

function Navbar() {
    const location = useLocation();

    const handleLogout = () => {
        localStorage.clear();
        window.location.href = "/";
    };

    const isRestrictedPage = location.pathname === "/" || location.pathname === "/register";

    return (
        <nav className="custom-navbar">
            <div className="custom-navbar-container">
                <div className="custom-navbar-logo">
                    <Link to="/" className="custom-navbar-brand">
                        EduLearn
                    </Link>
                </div>

                {!isRestrictedPage && (
                    <>
                        <ul className="custom-navbar-nav">
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/home">
                                    Home
                                </Link>
                            </li>
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/courses">
                                    Courses
                                </Link>
                            </li>
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/dashboard">
                                    Dashboard
                                </Link>
                            </li>
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/profile">
                                    Profile
                                </Link>
                            </li>
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/about">
                                    About Us
                                </Link>
                            </li>
                            <li className="custom-nav-item">
                                <Link className="custom-nav-link" to="/contact">
                                    Contact Us
                                </Link>
                            </li>
                        </ul>
                        <div className="custom-navbar-logout">
                            <Link onClick={handleLogout} className="logout-link">
                                <FaSignOutAlt className="logout-icon" />
                            </Link>
                        </div>
                    </>
                )}
            </div>
        </nav>
    );
}

export default Navbar;