import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Profile.css";
import profile from "../assets/profile.jpg";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Profile() {
    const [userData, setUserData] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [editData, setEditData] = useState({ name: "", email: "", mobileNumber: "", bio: "" });

    const userId = localStorage.getItem("userId");

    useEffect(() => {
        if (!userId) {
            console.error("User ID not found in local storage.");
            return;
        }
        axios
            .get(`http://localhost:5000/api/Users/${userId}`)
            .then((response) => setUserData(response.data))
            .catch((error) => console.error("Error fetching user data:", error));
    }, [userId]);

    const handleEditClick = () => {
        setEditData({ ...userData }); 
        setIsEditing(true);
    };

    const handleSave = () => {
        axios
            .put(`http://localhost:5000/api/Users/${userId}`, editData)
            .then(() => {
                setUserData(editData); 
                setIsEditing(false);
                toast.success("Profile updated successfully!");
            })
            .catch((error) => {
                console.error("Error updating profile:", error);
                toast.error("Failed to update profile. Please try again.");
            });
    };

    const handleDelete = () => {
        if (window.confirm("Are you sure you want to delete your account?")) {
            axios
                .delete(`http://localhost:5000/api/Users/${userId}`)
                .then(() => {
                    alert("Account deleted successfully!");
                    localStorage.clear();
                    window.location.href = "/"; 
                })
                .catch((error) => {
                    console.error("Error deleting account:", error);
                    alert("Failed to delete account. Please try again.");
                });
        }
    };

    if (!userData) {
        return <div>Loading profile...</div>;
    }

    return (
        <div className="profile-container">
            <div className="profile-card">
                <div className="profile-image">
                    <img src={profile} alt="Profile Illustration" />
                </div>
                <div className="profile-details">
                    <h2>Your Profile</h2>
                    {isEditing ? (
                        <div className="profile-info">
                            <label>
                                <strong>Name:</strong>
                                <input
                                    type="text"
                                    value={editData.name}
                                    onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                                />
                            </label>
                            <label>
                                <strong>Email:</strong>
                                <input
                                    type="email"
                                    value={editData.email}
                                    onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                                />
                            </label>
                            <label>
                                <strong>Mobile number:</strong>
                                <input
                                    type="text"
                                    value={editData.mobileNumber}
                                    onChange={(e) => setEditData({ ...editData, mobileNumber: e.target.value })}
                                />
                            </label>
                            <label>
                                <strong>Bio:</strong>
                                <textarea
                                    value={editData.bio}
                                    onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                                />
                            </label>
                            <button className="btn-save" onClick={handleSave}>
                                Save Changes
                            </button>
                            <button className="btn-cancel" onClick={() => setIsEditing(false)}>
                                Cancel
                            </button>
                        </div>
                    ) : (
                        <div className="profile-info">
                            <p><strong>Name:</strong> {userData.name}</p>
                            <p><strong>Email:</strong> {userData.email}</p>
                            <p><strong>Mobile number:</strong> {userData.mobileNumber}</p>
                            <p><strong>Bio:</strong> {userData.bio}</p>
                        </div>
                    )}
                    {!isEditing && (
                        <div className="profile-actions">
                            <button className="btn-edit" onClick={handleEditClick}>
                                Edit Profile
                            </button>
                            <button className="btn-delete" onClick={handleDelete}>
                                Delete Account
                            </button>
                        </div>
                    )}
                </div>
            </div>
            <ToastContainer position="top-right" autoClose={3000} />
        </div>
    );
}

export default Profile;