import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import register from "../assets/register.jpg";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "./Register.css";
import axios from "axios";

const Register = () => {
    const [Email, setEmail] = useState("");
    const [PasswordHash, setPassword] = useState("");
    const [Name, setName] = useState("");
    const [Bio, setBio] = useState("");
    const [MobileNumber, setMobileNumber] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError("");

        try {
            const response = await axios.post("http://localhost:5000/api/Auth/register", {
                id: 0,
                Name: Name,
                Email: Email,
                PasswordHash: PasswordHash,
                Bio: Bio,
                MobileNumber: MobileNumber,
            });

            if (response.status === 200 || response.status === 201) {
                toast.success("Registration successful!");
                setTimeout(() => {
                    navigate("/");
                }, 1000);
            } else {
                throw new Error("Registration failed. Please try again.");
            }
        } catch (err) {
            setError(err.response?.data?.message || err.message);
            toast.error(err.response?.data?.message || err.message);
        }
    };

    return (
        <div className="register-container">
            <div className="register-box">
                <h2>Sign Up</h2>
                <img className="signup-image" src={register} alt="SignUp" />
                <form className="register-form" onSubmit={handleSubmit}>
                    <input
                        type="text"
                        placeholder="Name"
                        value={Name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                    <input
                        type="email"
                        placeholder="Email"
                        value={Email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={PasswordHash}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <button className="signup-button" type="submit">Register</button>
                </form>
                {error && <p className="error-message">{error}</p>}
            </div>
            <ToastContainer position="top-right" autoClose={1000} />
        </div>
    );
};

export default Register;