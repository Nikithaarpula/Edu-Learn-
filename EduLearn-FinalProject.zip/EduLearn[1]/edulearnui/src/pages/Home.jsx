import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./Home.css";
import "bootstrap/dist/css/bootstrap.min.css";
import image1 from "../assets/carousal1.jpg";
import image2 from "../assets/carousal2.png";
import image3 from "../assets/carousal3.jpg";
import reactCourseImage from "../assets/react-course.jpg";
import javascriptCourseImage from "../assets/javascript-course.jpg";
import htmlCssCourseImage from "../assets/html-css-course.png";
import nodejsCourseImage from "../assets/nodejs-course.png";
import pythonCourseImage from "../assets/python-course.jpg";
import dsaCourseImage from "../assets/dsa-course.png";
import mlCourseImage from "../assets/ml-course.jpg";
import uiuxCourseImage from "../assets/uiux-course.jpg";
import reactAdvancedCourseImage from "../assets/react-advanced-course.jpg";
import javaCourseImage from "../assets/java-course.png";
import csharpCourseImage from "../assets/csharp-course.png";
import sqlCourseImage from "../assets/sql-course.jpg";
import awsCourseImage from "../assets/aws-course.jpg";
import dockerCourseImage from "../assets/docker-course.jpg";
import kubernetesCourseImage from "../assets/kubernetes-course.png";

function Home() {
    const [featuredCourses, setFeaturedCourses] = useState([]);

    useEffect(() => {
        axios
            .get("http://localhost:5000/api/courses")
            .then((response) => {
                const courses = response.data.map((course) => ({
                    ...course,
                    image: getImageSource(course.title),
                }));
                const shuffledCourses = courses.sort(() => 0.5 - Math.random());
                const selectedCourses = shuffledCourses.slice(0, 5);
                setFeaturedCourses(selectedCourses);
                console.log(selectedCourses);
            })
            .catch((error) => {
                console.error("Error fetching courses:", error);
            });
    }, []);

    const getImageSource = (title) => {
        const imageMapping = {
            "React Basics": reactCourseImage,
            "Advanced JavaScript": javascriptCourseImage,
            "HTML & CSS Fundamentals": htmlCssCourseImage,
            "Node.js Essentials": nodejsCourseImage,
            "Python for Beginners": pythonCourseImage,
            "Data Structures & Algorithms": dsaCourseImage,
            "Machine Learning Basics": mlCourseImage,
            "UI/UX Design Principles": uiuxCourseImage,
            "React Advanced": reactAdvancedCourseImage,
            "Java Programming": javaCourseImage,
            "C# Fundamentals": csharpCourseImage,
            "SQL for Beginners": sqlCourseImage,
            "AWS Cloud Basics": awsCourseImage,
            "Docker Essentials": dockerCourseImage,
            "Kubernetes Introduction": kubernetesCourseImage,
        };
        return imageMapping[title];
    };

    return (
        <div className="home-container">
            <div className="welcome-section"></div>
            <div className="carousel-section">
                <div
                    id="featuredCoursesCarousel"
                    className="carousel slide"
                    data-bs-ride="carousel"
                >
                    <div className="carousel-inner">
                        <div className="carousel-item active">
                            <img src={image1} className="d-block w-100" alt="Slide 1" />
                        </div>
                        <div className="carousel-item">
                            <img src={image2} className="d-block w-100" alt="Slide 2" />
                        </div>
                        <div className="carousel-item">
                            <img src={image3} className="d-block w-100" alt="Slide 3" />
                        </div>
                    </div>
                    <button
                        className="carousel-control-prev"
                        type="button"
                        data-bs-target="#featuredCoursesCarousel"
                        data-bs-slide="prev"
                    >
                        <span
                            className="carousel-control-prev-icon"
                            aria-hidden="true"
                        ></span>
                        <span className="visually-hidden">Previous</span>
                    </button>
                    <button
                        className="carousel-control-next"
                        type="button"
                        data-bs-target="#featuredCoursesCarousel"
                        data-bs-slide="next"
                    >
                        <span
                            className="carousel-control-next-icon"
                            aria-hidden="true"
                        ></span>
                        <span className="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div className="featured-section">
                <h2>Featured Courses</h2>
                <div className="row">
                    {featuredCourses.map((course) => (
                        <div className="col-md-4" key={course.id}>
                            <div className="card shadow-sm">
                                <img
                                    src={course.image}
                                    className="card-img-top"
                                    alt={course.title}
                                />
                                <div className="card-body">
                                    <h5 className="card-title">{course.title}</h5>
                                    <p className="card-text">{course.caption}</p>
                                    <Link to={`/courses/${course.id}`} className="btn btn-primary">
                                        View Details
                                    </Link>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Home;