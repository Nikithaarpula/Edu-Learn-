import React from 'react';

function Quiz() {
  return (
    <div> Quiz</div>
  );
}

export default Quiz;