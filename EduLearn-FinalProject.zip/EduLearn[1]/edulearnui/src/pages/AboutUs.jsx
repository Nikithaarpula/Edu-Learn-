import React from "react";
import "./AboutUs.css";
import aboutUs from "../assets/aboutUs.jpg"
import { Link

 } from "react-router-dom";
function AboutUs() {
  return (
    <div className="about-container">
      <div className="about-content">
        <h1 className="about-heading">EDULEARN</h1>
        <h1 className="about-subheading">
          Best Education Platform For Learning
        </h1>
        <p className="about-description">
        EduLearn is a dynamic platform transforming how people learn and grow. With a mission to make quality education accessible, we offer diverse courses across various disciplines for learners of all levels. Combining expert instruction with interactive features, EduLearn creates a seamless and engaging learning experience. Our flexible schedules and personalized progress tracking empower users to achieve their goals at their own pace. At EduLearn, we believe education unlocks potential, fosters creativity, and drives success. Join our community of passionate learners and educators as we inspire learning, spark curiosity, and build a brighter future together.
        </p>
        <Link to="/home" className="btn btn-primary">
          Start Now
        </Link>
      </div>
      <div className="about-image">
        <img
          src={aboutUs}
          alt="About EduLearn"
          className="img-fluid"
        />
      </div>
    </div>
  );
}

export default AboutUs;