import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ContactUs.css";
import contactus from "../assets/contactus.jpg";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function ContactUs() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        message: "",
    });
    const [submissionStatus, setSubmissionStatus] = useState(null);
    const [contactCount, setContactCount] = useState(0);

    useEffect(() => {
        axios
            .get("http://localhost:5000/api/contact")
            .then((response) => {
                setContactCount(response.data);
            })
            .catch((error) => {
                console.error("Error fetching contact count:", error);
            });
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const userId = localStorage.getItem("userId") || 0; 
            const newContactId = contactCount + 1;

            await axios.post("http://localhost:5000/api/contact", {
                id: newContactId,
                ...formData,
                userId,
            });

            setSubmissionStatus("Message sent successfully!");
            toast.success("Message sent successfully!");
            setFormData({
                name: "",
                email: "",
                message: "",
            });
            setContactCount((prevCount) => prevCount + 1); // Update count locally
        } catch (error) {
            console.error("Error submitting contact request:", error);
            setSubmissionStatus("Failed to send message. Please try again.");
        }
    };

    return (
        <div className="contact-container">
            <div className="contact-form">
                <h2>Contact Us</h2>
                {submissionStatus && <p className="submission-status">{submissionStatus}</p>}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <input
                            type="text"
                            name="name"
                            placeholder="Name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <input
                            type="email"
                            name="email"
                            placeholder="Enter a valid email address"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <textarea
                            name="message"
                            placeholder="Enter your message"
                            value={formData.message}
                            onChange={handleChange}
                            rows="4"
                            required
                        ></textarea>
                    </div>
                    <button type="submit" className="btn-submit">
                        Submit
                    </button>
                </form>
            </div>
            <div className="contact-image">
                <img src={contactus} alt="Contact" />
            </div>
            <ToastContainer position="top-right" autoClose={3000} />
        </div>
    );
}

export default ContactUs;