import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import login from "../assets/login.jpg";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./Login.css";

const Login = () => {
    const [email, setEmail] = useState("");
    const [passwordHash, setPasswordHash] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        setError("");

        try {
            const response = await axios.post(
                `http://localhost:5000/api/Auth/login?Email=${encodeURIComponent(
                    email
                )}&PasswordHash=${encodeURIComponent(passwordHash)}`
            );

            const { token } = response.data.token;
            toast.success("Login successful!");
            console.log(response);
            localStorage.setItem("userId", response.data.userId); 
            localStorage.setItem("userToken", token);
            setTimeout(() => {
                navigate("/home");
            }, 1000)
        } catch (err) {
            const errorMessage = err.response?.data || "Failed to login. Please try again.";
            setError(errorMessage);
            toast.error(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    const handleShowPasswordToggle = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div className="login-form-container">
            <img src={login} className="login-image" alt="loginImage" />
            <form className="login-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <input
                        type="email"
                        value={email}
                        placeholder="Email"
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <input
                        type={showPassword ? "text" : "password"}
                        value={passwordHash}
                        placeholder="Password"
                        onChange={(e) => setPasswordHash(e.target.value)}
                        required
                    />
                </div>
                <div className="form-options">
                    <label>
                        <input
                            type="checkbox"
                            checked={showPassword}
                            onChange={handleShowPasswordToggle}
                        />
                        Show Password
                    </label>
                </div>
                {error && <p className="error-message">{error}</p>}
                <button type="submit" className="login-button" disabled={loading}>
                    {loading ? "Logging in..." : "LOGIN"}
                </button>
                <div className="signup-container">
                    <Link to="/register" className="forgot-password">
                        Don't have an account? Sign Up
                    </Link>
                </div>
            </form>
            <ToastContainer position="top-right" autoClose={1000} />
        </div>
    );
};

export default Login;