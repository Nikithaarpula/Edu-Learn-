import React from 'react';

function DiscussionForum() {
  return (
    <div> DiscussionForum</div>
  );
}

export default DiscussionForum;