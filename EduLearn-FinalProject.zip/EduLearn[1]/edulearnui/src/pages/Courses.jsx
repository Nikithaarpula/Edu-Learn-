import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Courses.css";
import reactCourseImage from "../assets/react-course.jpg";
import javascriptCourseImage from "../assets/javascript-course.jpg";
import htmlCssCourseImage from "../assets/html-css-course.png";
import nodejsCourseImage from "../assets/nodejs-course.png";
import pythonCourseImage from "../assets/python-course.jpg";
import dsaCourseImage from "../assets/dsa-course.png";
import mlCourseImage from "../assets/ml-course.jpg";
import uiuxCourseImage from "../assets/uiux-course.jpg";
import reactAdvancedCourseImage from "../assets/react-advanced-course.jpg";
import javaCourseImage from "../assets/java-course.png";
import csharpCourseImage from "../assets/csharp-course.png";
import sqlCourseImage from "../assets/sql-course.jpg";
import awsCourseImage from "../assets/aws-course.jpg";
import dockerCourseImage from "../assets/docker-course.jpg";
import kubernetesCourseImage from "../assets/kubernetes-course.png";

function Courses() {
    const [courses, setCourses] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        axios
            .get("http://localhost:5000/api/courses")
            .then((response) => {
                const updatedCourses = response.data.map((course) => ({
                    ...course,
                    image: getImageSource(course.title),
                }));
                setCourses(updatedCourses);
            })
            .catch((error) => {
                console.error("Error fetching courses:", error);
            });
    }, []);

    const getImageSource = (title) => {
        const imageMapping = {
            "React Basics": reactCourseImage,
            "Advanced JavaScript": javascriptCourseImage,
            "HTML & CSS Fundamentals": htmlCssCourseImage,
            "Node.js Essentials": nodejsCourseImage,
            "Python for Beginners": pythonCourseImage,
            "Data Structures & Algorithms": dsaCourseImage,
            "Machine Learning Basics": mlCourseImage,
            "UI/UX Design Principles": uiuxCourseImage,
            "React Advanced": reactAdvancedCourseImage,
            "Java Programming": javaCourseImage,
            "C# Fundamentals": csharpCourseImage,
            "SQL for Beginners": sqlCourseImage,
            "AWS Cloud Basics": awsCourseImage,
            "Docker Essentials": dockerCourseImage,
            "Kubernetes Introduction": kubernetesCourseImage,
        };
        return imageMapping[title];
    };

    const filteredCourses = courses.filter((course) =>
        course.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="courses-container container">
            <h2>Available Courses</h2>
            <input
                type="text"
                className="form-control mb-3"
                placeholder="Search for courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="row">
                {filteredCourses.length > 0 ? (
                    filteredCourses.map((course) => (
                        <div className="col-md-4" key={course.id}>
                            <div className="card shadow-sm">
                                <img
                                    src={course.image}
                                    className="card-img-top"
                                    alt={course.title}
                                />
                                <div className="card-body">
                                    <h5 className="card-title">{course.title}</h5>
                                    <p className="card-text">{course.caption}</p>
                                    <button
                                        className="btn btn-primary"
                                        onClick={() => navigate(`/courses/${course.id}`)}
                                    >
                                        View Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <p>No courses found.</p>
                )}
            </div>
        </div>
    );
}

export default Courses;