import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Dashboard.css";

// Import all course images
import reactCourseImage from "../assets/react-course.jpg";
import javascriptCourseImage from "../assets/javascript-course.jpg";
import htmlCssCourseImage from "../assets/html-css-course.png";
import nodejsCourseImage from "../assets/nodejs-course.png";
import pythonCourseImage from "../assets/python-course.jpg";
import dsaCourseImage from "../assets/dsa-course.png";
import mlCourseImage from "../assets/ml-course.jpg";
import uiuxCourseImage from "../assets/uiux-course.jpg";
import reactAdvancedCourseImage from "../assets/react-advanced-course.jpg";
import javaCourseImage from "../assets/java-course.png";
import csharpCourseImage from "../assets/csharp-course.png";
import sqlCourseImage from "../assets/sql-course.jpg";
import awsCourseImage from "../assets/aws-course.jpg";
import dockerCourseImage from "../assets/docker-course.jpg";
import kubernetesCourseImage from "../assets/kubernetes-course.png";

function Dashboard() {
    const [courses, setCourses] = useState([]);
    const [enrollmentCount, setEnrollmentCount] = useState(0);

    useEffect(() => {
        const userId = localStorage.getItem("userId");
        if (!userId) {
            console.error("User ID not found in local storage.");
            return;
        }

        // Fetch enrolled courses
        axios
            .get(`http://localhost:5000/api/Enrollment`)
            .then((response) => {
                setEnrollmentCount(response.data); // Assuming response contains count
                if (response.data > 0) {
                    axios
                        .get(`http://localhost:5000/api/Enrollment/${userId}`)
                        .then((courseResponse) => {
                            const updatedCourses = courseResponse.data.map((enrollment) => {
                                const { course } = enrollment;
                                return {
                                    ...course,
                                    image: getImageSource(course.title),
                                };
                            });
                            setCourses(updatedCourses);
                        })
                        .catch((error) =>
                            console.error("Error fetching courses for the user:", error)
                        );
                }
            })
            .catch((error) => console.error("Error fetching enrollment count:", error));
    }, []);

    const getImageSource = (title) => {
        const imageMapping = {
            "React Basics": reactCourseImage,
            "Advanced JavaScript": javascriptCourseImage,
            "HTML & CSS Fundamentals": htmlCssCourseImage,
            "Node.js Essentials": nodejsCourseImage,
            "Python for Beginners": pythonCourseImage,
            "Data Structures & Algorithms": dsaCourseImage,
            "Machine Learning Basics": mlCourseImage,
            "UI/UX Design Principles": uiuxCourseImage,
            "React Advanced": reactAdvancedCourseImage,
            "Java Programming": javaCourseImage,
            "C# Fundamentals": csharpCourseImage,
            "SQL for Beginners": sqlCourseImage,
            "AWS Cloud Basics": awsCourseImage,
            "Docker Essentials": dockerCourseImage,
            "Kubernetes Introduction": kubernetesCourseImage,
        };
        return imageMapping[title] || "/assets/course-placeholder.jpg"; // Default image
    };

    return (
        <div className="dashboard-container container mt-5">
            <h2>My Dashboard</h2>
            <p>Your progress and enrolled courses.</p>
            <div className="row">
                {courses.length > 0 ? (
                    courses.map((course) => (
                        <div className="col-md-4" key={course.id}>
                            <div className="card shadow-sm mb-4">
                                <img
                                    src={course.image}
                                    className="card-img-top"
                                    alt={course.title}
                                />
                                <div className="card-body">
                                    <h5 className="card-title">{course.title}</h5>
                                    <p className="card-text">{course.caption}</p>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="no-courses">No enrolled courses found.</p>
                )}
            </div>
        </div>
    );
}

export default Dashboard;